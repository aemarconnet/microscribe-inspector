@echo off
"%~dp0MicroScribeInspector.exe" /install /desktop

